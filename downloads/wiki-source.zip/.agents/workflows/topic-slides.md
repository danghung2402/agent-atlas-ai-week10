# topic-slides — Wiki → 教學 HTML

觸發：主題、來源或逐頁稿變更。執行者先讀 AGENTS.md 與 requirements.md。

1. 取得至少五篇原始來源。既有固定版本與雜湊不得覆寫；缺資料時停止，回報缺口。
2. 每篇來源各抽取 evidence cards：主張、source ID、PDF page、section、定位詞、限制。立即執行 `python scripts/check_sources.py`，保存 evidence/topic-revision/sources-gate.json；這一步不讀 dist，也不執行 build。通過後才可改寫 Wiki，失敗則留在本關。
3. 先做來源筆記，再整理概念與問答；更新關聯、反向連結與 wiki/log.md。
4. 在 Wiki 以教學問題查詢並保存 queries.json。檢查所有五篇來源有對應證據。
5. 產生 8–15 頁的大綱與逐頁稿，保存 deck.json。每頁 evidence 必須來自本次選取集合。
6. 先完成案例重跑與 JS/Python 一致性，再凍結本輪輸入並對照逐頁稿與引用原文做忠實度核對。本輪使用 evidence/scheduling-review.json，保存新內容的輸入雜湊與 reviewer；不可把舊主題複核當成本輪通過。
7. `python scripts/build.py`：只渲染已保存的內容，不改寫文字。
8. `python scripts/check.py`：核對來源雜湊、頁碼、引用、覆蓋、內部參照與逐頁稿一致性。
9. 用瀏覽器檢查頁面、鍵盤、搜尋、測驗、講者筆記和窄畫面；保存真實觀察。
10. 來源／證據錯 → 回 1–2；知識缺口 → 回 3–4；逐頁引用錯 → 回 5；版面／操作錯 → 回 7。

每個節點最多三輪修正；全部關卡通過才交件。超過上限、來源不足或無法核驗即停止並回報，不能補造。
程式不會自動呼叫模型或自行編輯；本次由 AI 依上述規則推進節點。
